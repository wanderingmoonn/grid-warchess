from pathlib import Path
import json
import os
import sys

ROOT = Path(__file__).resolve().parent
runtime = ROOT / 'plot-runtime'
if not runtime.exists():
    runtime = ROOT.parent / 'unit-mismatch-review-20261108' / 'plot-runtime'
sys.path.insert(0, str(runtime))
os.environ['MPLCONFIGDIR'] = str(ROOT / 'plot-cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties

data = json.loads((ROOT / 'comparison.json').read_text(encoding='utf-8'))
assets = ROOT / 'assets'
assets.mkdir(exist_ok=True)
font_path = Path('C:/Windows/Fonts/msyh.ttc')
font = FontProperties(fname=str(font_path)) if font_path.exists() else FontProperties()
plt.rcParams.update({'font.size': 11, 'axes.spines.top': False, 'axes.spines.right': False, 'axes.axisbelow': True, 'svg.fonttype': 'path'})

def fonts(ax):
    for text in [ax.title, ax.xaxis.label, ax.yaxis.label, *ax.get_xticklabels(), *ax.get_yticklabels()]:
        text.set_fontproperties(font)
    if ax.get_legend():
        for text in ax.get_legend().get_texts():
            text.set_fontproperties(font)

fig, ax = plt.subplots(figsize=(10.4, 4.7), layout='constrained')
rows = [(r[version], version) for r in data['totals'] for version in ['before', 'after']]
y = list(range(6))
left = [0] * 6
for key, label, color in [('win', '胜', '#317b69'), ('loss', '负', '#c26860'), ('capped', '到上限未决', '#a7a9b1')]:
    values = [r['outcomes'][key] for r, version in rows]
    ax.barh(y, values, left=left, color=color, label=label, height=.65)
    for i, value in enumerate(values):
        if value:
            ax.text(left[i] + value / 2, i, str(value), ha='center', va='center', color='white', weight='bold', fontsize=12)
    left = [a + b for a, b in zip(left, values)]
ax.set_yticks(y, [f"{r['name']} · {'优化前' if v == 'before' else '候选策略'}" for r, v in rows])
ax.invert_yaxis()
ax.set_xlim(0, 4)
ax.set_xticks([0, 1, 2, 3, 4])
ax.set_xlabel('局数（每种两张固定地图，各交换一次座位）')
ax.set_title('神圣骑士长出现两局负转胜，法师仍未验证战绩改善')
ax.legend(loc='lower right', bbox_to_anchor=(1, 1.02), ncols=3, frameon=False)
ax.grid(axis='x', alpha=.15)
fonts(ax)
fig.savefig(assets / 'outcomes.png', dpi=180)
fig.savefig(assets / 'outcomes.svg')
plt.close(fig)

holy = next(r for r in data['totals'] if r['id'] == 'holy-knight-lord')
old, new = holy['before']['banner'], holy['after']['banner']
fig, axs = plt.subplots(1, 2, figsize=(11.8, 4.6), layout='constrained')
labels = ['移动后插旗', '仍可先移动扩大覆盖', '未覆盖其他战斗单位']
keys = ['afterMove', 'legalImprovedCoverage', 'zeroOtherCombatRecipients']
old_values = [old[k] / old['casts'] * 100 for k in keys]
new_values = [new[k] / new['casts'] * 100 for k in keys]
x = list(range(3))
for offset, values, color, label in [(-.19, old_values, '#8596ac', '优化前'), (.19, new_values, '#357a9a', '候选策略')]:
    bars = axs[0].bar([i + offset for i in x], values, width=.36, color=color, label=label)
    axs[0].bar_label(bars, labels=[f'{v:.1f}%' for v in values], padding=3, fontsize=9)
axs[0].set_xticks(x, ['移动后插旗', '可扩大覆盖', '无其他战斗友军'])
axs[0].set_ylim(0, 60)
axs[0].set_ylabel('占全部施放次数的比例')
axs[0].set_title('移动顺序改善，仍存在低覆盖施放')
axs[0].legend(frameon=False)
for offset, source, color, label in [(-.19, old, '#8596ac', '优化前'), (.19, new, '#357a9a', '候选策略')]:
    values = [source['localSavings'][k] for k in ['self', 'otherCombat', 'nonCombat']]
    bars = axs[1].bar([i + offset for i in x], values, width=.36, color=color, label=label)
    axs[1].bar_label(bars, padding=3, fontsize=10)
axs[1].set_xticks(x, ['骑士长自身', '其他战斗单位', '桥梁等非战斗单位'])
axs[1].set_ylim(0, 175)
axs[1].set_ylabel('固定动作下的即时HP损失差额')
axs[1].set_title('圣旗保护差额增加，主要仍落在自身')
axs[1].legend(frameon=False)
for ax in axs:
    ax.grid(axis='y', alpha=.15)
    fonts(ax)
fig.savefig(assets / 'holy-banner.png', dpi=180)
fig.savefig(assets / 'holy-banner.svg')
plt.close(fig)
print(json.dumps({'plots': 2, 'matplotlib': matplotlib.__version__, 'oldCasts': old['casts'], 'newCasts': new['casts']}))
