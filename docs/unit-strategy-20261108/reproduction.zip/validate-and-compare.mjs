import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath,pathToFileURL} from 'node:url';

const dir=path.dirname(fileURLToPath(import.meta.url));
const old=fs.existsSync(path.join(dir,'reference/protocol.json'))?path.join(dir,'reference'):path.resolve(dir,'../unit-benchmark-20261108');
const oldReview=fs.existsSync(path.join(dir,'reference/replay-review.json'))?path.join(dir,'reference'):path.resolve(dir,'../unit-mismatch-review-20261108');
const read=(root,name)=>JSON.parse(fs.readFileSync(path.join(root,name),'utf8'));
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const protocol=read(dir,'protocol.json'),seal=read(dir,'seal.json'),originalProtocol=read(old,'protocol.json');
const review=read(dir,'replay-review.json'),priorReview=read(oldReview,'replay-review.json');
const probes=read(dir,'mechanic-and-position-probes.json'),priorProbes=read(oldReview,'mechanic-and-position-probes.json');
const {createMatch}=await import(pathToFileURL(path.join(dir,'baseline/core/setup.ts')).href);
const {prepareSimulation,applyAction}=await import(pathToFileURL(path.join(dir,'baseline/core/rules.ts')).href);
const {playerView}=await import(pathToFileURL(path.join(dir,'baseline/core/fog.ts')).href);
const add=(rows,key)=>rows.reduce((n,r)=>n+(r[key]??0),0);
const count=(rows,key)=>Object.fromEntries([...new Set(rows.map(r=>r[key]))].sort().map(k=>[k,rows.filter(r=>r[key]===k).length]));
const median=rows=>{const a=rows.filter(x=>x!==null).sort((a,b)=>a-b);return a.length?(a[Math.floor((a.length-1)/2)]+a[Math.ceil((a.length-1)/2)])/2:null;};
const targetIds=['ge','mage','holy-knight-lord'];
assert.equal(protocol.jobs.length,12);assert.equal(new Set(protocol.jobs.map(j=>j.id)).size,12);
assert.deepEqual(protocol.config,originalProtocol.config);
for(const k of ['cap','maxActions','budget','aiArmyCap','seeds'])assert.deepEqual(protocol[k],originalProtocol[k]);
for(const [file,fingerprint]of Object.entries(protocol.fingerprints))assert.equal(hash(fs.readFileSync(path.join(dir,'baseline/core',file))),fingerprint,file);
for(const [file,fingerprint]of Object.entries(protocol.candidateFingerprints))assert.equal(hash(fs.readFileSync(path.join(dir,'candidate/core',file))),fingerprint,file);
assert.equal(hash(JSON.stringify(protocol.candidateFingerprints)),protocol.candidateFingerprint);
assert.equal(seal.baseline,protocol.sourceFingerprint);assert.equal(seal.candidate,protocol.candidateFingerprint);
for(const [file,fingerprint]of Object.entries(seal.harness))assert.equal(hash(fs.readFileSync(path.join(dir,file))),fingerprint,'Sealed harness '+file);
const changed=Object.keys(protocol.candidateFingerprints).filter(f=>protocol.candidateFingerprints[f]!==protocol.fingerprints[f]).sort();
assert.deepEqual(changed,['ai-meta.ts','ai-unit-strategy.ts','ai.ts']);
const loadReplay=(root,id)=>JSON.parse(zlib.gunzipSync(fs.readFileSync(path.join(root,'games',id+'.replay.json.gz'))));
const cases=[];
for(const job of protocol.jobs){
 const a=read(old,'games/'+job.id+'.json'),b=read(dir,'games/'+job.id+'.json');
 const ga=priorReview.games.find(g=>g.id===job.id),gb=review.games.find(g=>g.id===job.id);
 assert.ok(ga&&gb);assert.ok(ga.finalVerified&&gb.finalVerified);
 assert.equal(a.prefixHash,b.prefixHash);assert.equal(a.startStateHash,b.startStateHash);assert.equal(a.prepEndTurn,b.prepEndTurn);
 assert.equal(b.testedController,'candidate');assert.equal(b.opponentController,'baseline');assert.equal(b.candidateFingerprint,seal.candidate);
 for(const [raw,g]of [[a,ga],[b,gb]]){
  assert.equal(raw.terminalError,null);assert.equal(raw.rejected.A+raw.rejected.B,0);assert.equal(raw.badActions.length,0);
  assert.ok(raw.budgetAudit.maxRecruit<=2&&raw.budgetAudit.maxUpgrade<=1&&raw.budgetAudit.maxActions<=50);
  assert.equal(g.actionHash,raw.actionHash);assert.equal(g.winner,raw.winner);assert.equal(g.turns,raw.turns);
  assert.equal(g.lives.length,raw.focus.recruited);assert.equal(add(g.lives,'damage')+add(g.lives,'counterDamage'),raw.focus.unitDamage+raw.focus.counterDamage);
  assert.equal(add(g.lives,'cost'),raw.focus.spent);assert.equal(g.initialBought,raw.quota);
 }
 const ra=loadReplay(old,job.id),rb=loadReplay(dir,job.id);
 assert.deepEqual(ra.config,rb.config);assert.equal(ra.fog,true);assert.equal(rb.fog,true);
 assert.equal(createMatch(ra.config,ra.seed).version,4);assert.equal(ra.v,3);assert.equal(rb.v,3);
 for(const [r,raw]of [[ra,a],[rb,b]])assert.equal(hash(JSON.stringify(r.actions)),raw.actionHash);
 let i=0;while(i<Math.min(ra.actions.length,rb.actions.length)&&JSON.stringify(ra.actions[i])===JSON.stringify(rb.actions[i]))i++;
 let firstDivergence=null;
 if(i<Math.max(ra.actions.length,rb.actions.length)){
  let s=prepareSimulation(createMatch(ra.config,ra.seed));
  for(let j=0;j<i;j++){const r=applyAction(s,ra.actions[j]);assert.ok(r.ok);s=r.state;}
  const view=playerView(s,s.current).state;
  firstDivergence={step:i,turn:s.turn,current:s.current,before:ra.actions[i]??null,after:rb.actions[i]??null,gold:s.players[s.current].gold,
   visibleOwnCombat:view.units.filter(u=>u.owner===s.current&&view.unitTypes[u.type].category==='combat').map(u=>({id:u.id,type:u.type,x:u.x,y:u.y,hp:u.hp})),
   visibleEnemyCombat:view.units.filter(u=>u.owner!==s.current&&view.unitTypes[u.type].category==='combat').map(u=>({id:u.id,type:u.type,x:u.x,y:u.y,hp:u.hp}))};
 }
 const simple=(raw,g)=>({outcome:raw.outcome,turnsConsumed:raw.turnsConsumed,actionCount:raw.actionCount,paid:raw.focus.recruited,spend:raw.focus.spent,
  firstRecruitTurn:raw.focus.firstRecruitTurn,quotaCompleteTurn:g.quotaCompleteTurn,firstEra4Turn:g.upgrades.find(u=>u.owner===job.seat&&u.era===4)?.turn??null,
  attacks:raw.focus.attacks,unitDamage:raw.focus.unitDamage+raw.focus.counterDamage,cityDamage:raw.focus.cityDamage,deaths:g.lives.filter(l=>l.death&&!l.death.wasDisband).length,
  quotaPurchaseTurns:g.purchases.filter(x=>x.owner===job.seat&&x.type===job.target).slice(0,raw.quota).map(x=>x.turn),
  recruitsBeforeFocal:g.purchases.filter(x=>x.owner===job.seat&&x.turn<raw.focus.firstRecruitTurn).map(x=>({turn:x.turn,type:x.type,cost:x.cost})),
  totalOwnRecruitSpend:raw.spend[job.seat],bannerCasts:g.bannerCasts.length,bannerLocalHpDifference:g.bannerHpSaved});
 cases.push({...job,before:simple(a,ga),after:simple(b,gb),sameActionHash:a.actionHash===b.actionHash,firstDivergence,
  purchaseDecisionReasons:count(b.strategyDecisions.filter(d=>['RECRUIT','UPGRADE'].includes(d.action.type)&&d.focus),'purchaseReason')});
}
function aggregate(id,games,p){
 const rows=games.filter(g=>g.target===id),lives=rows.flatMap(g=>g.lives),casts=rows.flatMap(g=>g.bannerCasts),positions=p.bannerPositions.filter(c=>rows.some(g=>g.id===c.game));
 const beneficiaries=rows.flatMap(g=>g.bannerHits.flatMap(h=>h.beneficiaries));
 const unitTypes=JSON.parse(zlib.gunzipSync(fs.readFileSync(path.join(dir,'key-frames.json.gz'))))[0].state.unitTypes;
 const savings={self:0,otherCombat:0,nonCombat:0,byType:{}};
 for(const b of beneficiaries){savings[b.type===id?'self':unitTypes[b.type]?.category==='combat'?'otherCombat':'nonCombat']+=b.hpSaved;savings.byType[b.type]=(savings.byType[b.type]??0)+b.hpSaved;}
 assert.equal(savings.self+savings.otherCombat+savings.nonCombat,add(rows,'bannerHpSaved'));
 const unused=rows.flatMap(g=>g.unused);
 const killers={};for(const l of lives.filter(l=>l.death&&!l.death.wasDisband)){const k=l.death.attacker?.type??l.death.action;killers[k]=(killers[k]??0)+1;}
 const reasons=unused.filter(u=>u.cities.length||u.targets.some(t=>t.unit.category==='combat'));
 return {id,name:protocol.targets.find(t=>t.id===id).name,games:rows.length,outcomes:{win:rows.filter(g=>g.outcome==='win').length,loss:rows.filter(g=>g.outcome==='loss').length,capped:rows.filter(g=>g.outcome==='capped').length},
  paid:lives.length,recruitSpend:add(lives,'cost'),initialSpend:add(rows,'initialSpend'),attacks:add(lives,'attacks'),damage:add(lives,'damage')+add(lives,'counterDamage'),activeDamage:add(lives,'damage'),counterDamage:add(lives,'counterDamage'),cityDamage:add(lives,'cityDamage'),
  damagePer100Gold:(add(lives,'damage')+add(lives,'counterDamage'))/add(lives,'cost')*100,
  moves:add(lives,'moves'),deaths:lives.filter(l=>l.death&&!l.death.wasDisband).length,zeroAttackDeaths:lives.filter(l=>l.death&&!l.death.wasDisband&&!l.attacks).length,
  fullHpAttackDeaths:lives.filter(l=>l.death?.action==='ATTACK'&&l.death.lastHp===unitTypes[l.type].maxHp).length,killers,
  medianOwnTurnsToFirstAttack:median(lives.filter(l=>l.firstAttackTurn!==null).map(l=>(l.firstAttackTurn-l.bornTurn)/2)),
  firstEra4Turns:rows.map(g=>g.upgrades.find(u=>u.owner===g.seat&&u.era===4)?.turn??null),firstRecruitTurns:rows.map(g=>g.lives[0]?.bornTurn??null),quotaCompleteTurns:rows.map(g=>g.quotaCompleteTurn),
  unusedPositiveShots:unused.length,unusedCombatOrCity:reasons.length,
  banner:{casts:casts.length,afterMove:casts.filter(c=>c.movedBeforeCast).length,beforeMove:casts.filter(c=>!c.movedBeforeCast).length,
   totalOtherCombatRecipients:positions.reduce((n,c)=>n+c.otherCombatRecipients,0),meanOtherCombatRecipients:positions.length?positions.reduce((n,c)=>n+c.otherCombatRecipients,0)/positions.length:0,
   zeroOtherCombatRecipients:positions.filter(c=>c.otherCombatRecipients===0).length,legalImprovedCoverage:positions.filter(c=>c.alternative).length,
   localHpDifference:add(rows,'bannerHpSaved'),localSavings:savings}};
}
const totals=targetIds.map(id=>({id,before:aggregate(id,priorReview.games,priorProbes),after:aggregate(id,review.games,probes)}));
for(const id of targetIds){const rows=cases.filter(c=>c.target===id);assert.equal(rows.length,4);assert.deepEqual(rows.map(c=>c.seed+'/'+c.seat).sort(),['218600/A','218600/B','218601/A','218601/B']);}
assert.ok(cases.filter(c=>c.target==='ge').every(c=>c.sameActionHash));
const result={scope:{newGames:12,reusedBeforeGames:12,maps:2,seeds:protocol.seeds,gamesPerType:4,halfTurnCap:200,nativeStateVersion:4,replaySchemaVersion:3,fog:true,types:targetIds,pairedBy:'same seed, target, seat, config and native preparation hash'},
 baselineFingerprint:seal.baseline,candidateFingerprint:seal.candidate,changedCoreFiles:changed,unitAndRuleFilesUnchanged:true,
 totals,cases,probeComparison:{mageKnownStationaryLethalMoves:{before:priorProbes.mageNewKnownLethalMoves.length,after:probes.mageNewKnownLethalMoves.length},
  mageKilledByKnownNextTurn:{before:priorProbes.mageNewKnownLethalMoves.filter(m=>m.killedByKnownThreatNextTurn).length,after:probes.mageNewKnownLethalMoves.filter(m=>m.killedByKnownThreatNextTurn).length}},
 limitations:['Four games per type share two maps; seat exchange is paired, not four independent map samples. No population win-rate claim or rating adjustment.',
  'Capped means no native winner by200 single-side turns. It is not a formal draw, half-win or loss.',
  'Procurement and tactics change together; this estimates the whole package against the frozen original opponent, not each component separately.',
  'Holy knight starts from the same legally paid era4 development prefix, which remains part of the200-turn cap.',
  'Instant HP output, cost efficiency and single-action banner ablations are descriptive/local quantities, not causal whole-game win estimates.']};
fs.writeFileSync(path.join(dir,'comparison.json'),JSON.stringify(result,null,2));
const validation={complete:true,newGames:12,reusedBeforeGames:12,nativeReplayAudited:12,nativeStateVersion:4,replaySchemaVersion:3,fog:true,pairedStartHashesMatch:true,ruleRejections:0,budgetViolations:0,sealedFilesMatch:true,changedCoreFiles:changed,unitAndRuleFilesUnchanged:true,geAllFourActionHashesIdentical:true,candidateFingerprint:seal.candidate,baselineFingerprint:seal.baseline};
fs.writeFileSync(path.join(dir,'comparison-validation.json'),JSON.stringify(validation,null,2));
console.log(JSON.stringify({validation,totals,cases:cases.map(c=>({id:c.id,before:c.before.outcome,after:c.after.outcome,firstDivergence:c.firstDivergence?{step:c.firstDivergence.step,turn:c.firstDivergence.turn,before:c.firstDivergence.before,after:c.firstDivergence.after}:null}))},null,2));
