/**
 * 时代兵种扩展包（大型模组）。
 *
 * 五个时代各出一套，取材自该时代真实存在的兵种、攻城器械与防御工事。
 * 每套的单位数量都**超过原版同期**（原版：青铜 13 / 铁器 10 / 火器 11 / 蒸汽 7 / 现代 11），
 * 目的是让"同一代"里出现真正的兵种选择，而不是"挑最贵那个"。
 *
 * ---------------------------------------------------------------
 * 数值是怎么定的（否则后面没法解释平衡报告）
 * ---------------------------------------------------------------
 * 先给每个单位算两个粗指标，再对照原版同代单位校准：
 *
 *   有效耐久 EHP = maxHp + 2 × armor
 *     （伤害模型是"攻击 − 护甲"直接相减，所以 1 点护甲 ≈ 2 点血）
 *   有效输出 DPS = atk × 段数系数
 *     段数系数：burst 取 burst；splash 取 1 + 0.5 × splash（溅射只吃一半伤害）
 *
 * 原版同代的每金耐久带（EHP / cost），本文件所有单位都落在带内或略低：
 *   青铜 0.60~1.28　铁器 0.29~0.71　火器 0.17~0.44
 *   蒸汽 0.22~0.38　现代 0.16~0.32
 *
 * 也就是说：**新单位不是"更强"，而是"更专"**。重甲的每金输出低、远程的每金
 * 耐久低、攻城器离开了城墙几乎是废铁——换来的才是在某个场景里明显好用。
 * 每金耐久普遍压在带的下沿（不是上沿），是为了让"多了一种兵"不至于变成
 * "整体变强"，否则模组一开，对局节奏就会整体漂移。
 *
 * ---------------------------------------------------------------
 * 一条硬约束：era 1 的战斗单位会被开局白送
 * ---------------------------------------------------------------
 * setup.ts 的开局部队只从 `era === 1 && category === 'combat'` 的池子里取，
 * 而且不看价钱——池子里有战象，开局就白送战象。所以青铜包里的战斗单位
 * 一律压在 60 金以内（这也是战象被压到 60、而真实的战象应该更贵的原因：
 * 宁可牺牲一点"贵气"，也不要让开局白送的东西打破基准）。
 *
 * 另外：开局的 2 个经济单位也是从 era 1 的 economy 里轮取的，所以青铜包
 * 故意不做经济单位，免得把农民/牧民挤出开局。
 */

import type { AbilityDef } from './abilities.ts';
// 第六时代的 15 个专精兵和他们那一套能力仍然定义在 contemporary-packs.ts 里
// （那边有按 EHP 校准过的数值口径），这里只负责把它们并进同一个包。
// 依赖方向是单向的：era-packs → contemporary-packs，反过来没有引用。
import { CONTEMPORARY_WAR, MODERN_ABILITIES } from './contemporary-packs.ts';
import { TURN_START } from './ability-hooks.ts';
import type { Expansion } from './expansions.ts';
import { addMark, markCountOf, markKindOf, marksAt, marksOf, removeMark } from './marks.ts';
import type { MarkKindDef } from './marks.ts';
import type { UnitTypeDef } from './types.ts';

/* ================================================================== */
/* 时代 1 · 青铜（原版 13 个 → 模组 14 个）                            */
/* ================================================================== */

const ANTIQUITY: UnitTypeDef[] = [
  // ---- 战斗 ----
  {
    // 希腊/罗马的投石兵：最便宜的远程，专门用来磨重甲方阵的耐心
    id: 'anc_slinger',
    name: '投石兵',
    short: '石',
    era: 1,
    category: 'combat',
    cost: 30,
    move: 2,
    atk: 9,
    armor: 0,
    maxHp: 18,
    range: 3,
    vision: 3,
  },
  {
    // 罗马轻步兵：射程只有 2，但比弓手便宜、比投石兵扛打
    id: 'anc_javelineer',
    name: '标枪兵',
    short: '标',
    era: 1,
    category: 'combat',
    cost: 32,
    move: 2,
    atk: 12,
    armor: 1,
    maxHp: 20,
    range: 2,
    vision: 3,
  },


  {
    // 蛮族战斧手：没有甲，只有一下狠的。用得起、死得快
    id: 'anc_axeman',
    name: '战斧手',
    short: '斧',
    era: 1,
    category: 'combat',
    cost: 34,
    move: 2,
    atk: 19,
    armor: 1,
    maxHp: 30,
    range: 1,
    vision: 2,
  },
  {
    // 轻盾兵：跑得快、能藏林子，用来抢资源点和摸后排
    id: 'anc_skirmisher',
    name: '轻盾兵',
    short: '轻',
    era: 1,
    category: 'combat',
    cost: 32,
    move: 4,
    atk: 11,
    armor: 1,
    maxHp: 24,
    range: 1,
    vision: 4,
    abilities: ['stealth'],
  },
  {
    // 埃及/赫梯战车：青铜唯一的"高机动打击力量"，代价是脆
    id: 'anc_chariot',
    name: '战车',
    short: '车',
    era: 1,
    category: 'combat',
    cost: 52,
    move: 4,
    atk: 16,
    armor: 2,
    maxHp: 30,
    range: 1,
    vision: 3,
  },

  {
    // 攻城槌：唯一的用途是撞门，野战里几乎打不动人
    id: 'anc_ram',
    name: '攻城槌',
    short: '槌',
    era: 1,
    category: 'combat',
    cost: 46,
    move: 1,
    atk: 14,
    armor: 5,
    maxHp: 55,
    range: 1,
    vision: 1,
    abilities: ['siege-master'],
  },


  // ---- 工事 ----
  {
    // 瞭望塔：青铜的"眼睛"。
    // 第一版 atk 12 / 视野 5 / 75 金，实测每百金杀伤 72.7（原版箭塔 37.0）——
    // 视野 5 在 12×12 上等于半个棋盘，它永远先手开火。现在视野收到 4、攻击 12→10、
    // 价格提到 85：仍然是最好的侦察塔，但不再是"造了就赢"。
    id: 'anc_watchtower',
    name: '瞭望塔',
    short: '望',
    era: 1,
    category: 'building',
    cost: 85,
    move: 0,
    atk: 10,
    armor: 4,
    maxHp: 32,
    range: 4,
    vision: 4,
    autoAttack: true,
  },
  {
    // 栅栏：最便宜的堵路工事，专门用来卡河岸和桥头
    id: 'anc_palisade',
    name: '栅栏',
    short: '栅',
    era: 1,
    category: 'building',
    cost: 40,
    move: 0,
    atk: 0,
    armor: 3,
    maxHp: 45,
    range: 1,
    vision: 1,
    obstacle: true,
  },
  {
    // 夯土城墙：美索不达米亚到先秦的城垣做法，一层层夯出来的土墙。
    // 城墙这条线是贯穿五个时代的：每代一段，价格与耐久同步涨，
    // 每金耐久稳定在 1.0~1.2（比同代战斗单位高），代价是**完全不能动、几乎不能打**。
    id: 'anc_rammed_wall',
    name: '夯土城墙',
    short: '垣',
    era: 1,
    category: 'building',
    cost: 70,
    move: 0,
    atk: 0,
    armor: 5,
    maxHp: 75,
    range: 1,
    vision: 1,
    obstacle: true,
  },

  // ---- 建造与水军 ----
  {
    // 工匠：本包工事的唯一施工方，顺便保留架桥和军营能力
    id: 'anc_engineer',
    name: '工匠',
    short: '匠',
    era: 1,
    category: 'builder',
    cost: 55,
    move: 2,
    atk: 5,
    armor: 2,
    maxHp: 20,
    range: 1,
    vision: 2,
    builds: ['anc_palisade', 'anc_rammed_wall', 'anc_watchtower', 'bridge', 'camp'],
  },
  {
    // 三层桨战船：青铜海权的象征，撞角为主。
    // 实测每百金 49.5，是舢板（23.3）的两倍，攻击收到 14 压一压。
    id: 'anc_trireme',
    name: '三层桨战船',
    short: '桨',
    era: 1,
    category: 'combat',
    cost: 64,
    move: 3,
    atk: 14,
    armor: 3,
    maxHp: 42,
    range: 1,
    vision: 3,
    domain: 'water',
  },

  /*
   * 下面三个补的是"青铜时代只有希腊罗马"这个偏科。
   *
   * 青铜时代的战场在埃及、两河、商周同样热闹，而且各自有一套成熟兵种：
   * 努比亚弓手（埃及新王国，前 2000 年起就是雇佣弓手）、青铜剑士（商周与
   * 迈锡尼都有的近战精锐）、旌旗车（商周的战车指挥位）。旌旗车尤其重要——
   * 它是**第一代唯一的支援兵**，编制模板里那 15% 支援份额终于有东西可买。
   */
  {
    id: 'anc_nubian',
    name: '努比亚弓手',
    short: '努',
    era: 1,
    category: 'combat',
    cost: 38,
    move: 3,
    atk: 9,
    armor: 0,
    maxHp: 18,
    range: 4,
    vision: 4,
    abilities: ['stealth'],
  },
  {
    id: 'anc_bronzesword',
    name: '青铜剑士',
    short: '剑',
    era: 1,
    category: 'combat',
    cost: 36,
    move: 2,
    atk: 15,
    armor: 2,
    maxHp: 32,
    range: 1,
    vision: 2,
  },
  {
    id: 'anc_standard',
    name: '旌旗车',
    short: '旌',
    era: 1,
    category: 'combat',
    cost: 44,
    move: 3,
    atk: 2,
    armor: 1,
    maxHp: 30,
    range: 1,
    vision: 4,
    abilities: ['aura-command'],
  },

];

/* ================================================================== */
/* 时代 2 · 铁器（原版 8 个 → 模组 12 个）                             */
/* ================================================================== */

const MEDIEVAL: UnitTypeDef[] = [
  {
    // 重装军士：骑士下马之后的形态，比长枪兵贵、比骑士耐打
    id: 'med_manatarms',
    name: '重装军士',
    short: '士',
    era: 2,
    category: 'combat',
    cost: 78,
    move: 2,
    atk: 19,
    armor: 6,
    maxHp: 48,
    range: 1,
    vision: 2,
    abilities: ['shield-wall'],
  },
  {
    // 热那亚弩手：射程和破甲都在长弓之上，代价是慢。
    // 第一版 100 金 atk 18，打出场均每百金 55.3（长弓 31.7）——破甲在"人人有甲"的铁器
    // 太值钱。攻击收到 16、价格提到 110，让它变成"贵一点的解甲方案"而不是全面替代长弓。
    id: 'med_crossbow',
    name: '弩手',
    short: '弩',
    era: 2,
    category: 'combat',
    cost: 110,
    move: 2,
    atk: 14,
    armor: 1,
    maxHp: 24,
    range: 4,
    vision: 3,
    abilities: ['armor-pierce'],
  },
  {
    // 蒙古骑射手：打带跑。first-strike = 不挨反击，它就是靠这个活着的。
    // 实测每百金只有 20.1——AI 不会"打了就跑"，先手在它手里换不成价值。
    // 所以补偿的是纯数值（攻击 15→17、价格 120→110），而不是再加机制。
    // 第三轮反过来了：AI 学会绕后之后，first-strike 配"永远站在安全位置"等于无风险输出，
    // 采用率冲到 32.9%、成为铁器绝对主力（ratio 1.40）。攻击 17→13、价格 110→125 收回。
    id: 'med_horsearcher',
    name: '骑射手',
    short: '射',
    era: 2,
    category: 'combat',
    cost: 125,
    move: 5,
    atk: 13,
    armor: 2,
    maxHp: 30,
    range: 3,
    vision: 5,
    abilities: ['first-strike'],
  },
  {
    // 瑞士长矛兵：铁器的"反骑兵"答案，正面极硬
    id: 'med_pikeman',
    name: '瑞士长矛兵',
    short: '矛',
    era: 2,
    category: 'combat',
    cost: 74,
    move: 2,
    atk: 19,
    armor: 4,
    maxHp: 48,
    range: 1,
    vision: 2,
    abilities: ['shield-wall'],
  },
  {
    // 双手剑士：放弃盾牌换攻击，专破长枪方阵的缝
    id: 'med_doppelsoldner',
    name: '双手剑士',
    short: '剑',
    era: 2,
    category: 'combat',
    cost: 88,
    move: 2,
    atk: 27,
    armor: 3,
    maxHp: 42,
    range: 1,
    vision: 2,
  },
  {
    // 配重投石机：铁器攻城的标准答案，射程 5 压过所有塔
    id: 'med_trebuchet',
    name: '投石机',
    short: '投',
    era: 2,
    category: 'combat',
    cost: 128,
    move: 1,
    atk: 26,
    armor: 2,
    maxHp: 34,
    range: 5,
    vision: 2,
    splash: 1,
    abilities: ['siege-master'],
  },
  {
    // 攻城塔：不靠打，靠"把兵送到城墙下"。血厚甲厚，慢得离谱
    id: 'med_siegetower',
    name: '攻城塔',
    short: '塔',
    era: 2,
    category: 'combat',
    cost: 100,
    move: 1,
    atk: 8,
    armor: 7,
    maxHp: 90,
    range: 1,
    vision: 2,
    abilities: ['siege-master'],
  },
  {
    // 胡斯战车：把车连成车堡，是铁器少见的"移动工事"
    id: 'med_wagon',
    name: '战车堡',
    short: '堡',
    era: 2,
    category: 'combat',
    cost: 130,
    move: 2,
    atk: 14,
    armor: 8,
    maxHp: 60,
    range: 2,
    vision: 2,
    abilities: ['shield-wall'],
  },
  {
    // 主楼：城堡最后一道防线。石堡 2026-11-01 也升到射程 3 之后，
    // 主楼的优势不再是"多一格"，而是同一射程下更硬、更疼（+3 攻 / +2 甲 / +2 视野）。
    id: 'med_donjon',
    name: '主楼',
    short: '楼',
    era: 2,
    category: 'building',
    cost: 160,
    move: 0,
    atk: 16,
    armor: 9,
    maxHp: 60,
    range: 3,
    vision: 4,
    autoAttack: true,
  },
  {
    // 城墙：铁器这一段是石砌幕墙。名字从"城墙段"改成"城墙"——
    // 它是城墙这条线（夯土 → 石砌 → 土垒 → 混凝土 → 掩体墙）的第二环，不该只被读成"一段"。
    id: 'med_wall',
    name: '城墙',
    short: '墙',
    era: 2,
    category: 'building',
    cost: 90,
    move: 0,
    atk: 0,
    armor: 8,
    maxHp: 80,
    range: 1,
    vision: 1,
    obstacle: true,
  },
  {
    // 掘城兵：负责把城墙/主楼/寨垒立起来（铁器时代 sapper 的本义就是挖地道）
    id: 'med_sapper',
    name: '掘城兵',
    short: '掘',
    era: 2,
    category: 'builder',
    cost: 95,
    move: 2,
    atk: 4,
    armor: 2,
    maxHp: 22,
    range: 1,
    vision: 2,
    builds: ['med_wall', 'med_donjon', 'bridge', 'camp2'],
  },
  {
    // 齿轮帆船：铁器唯一能运兵过河的船，运 3 个
    id: 'med_cog',
    name: '齿轮帆船',
    short: '帆',
    era: 2,
    category: 'combat',
    cost: 98,
    move: 4,
    atk: 16,
    armor: 4,
    maxHp: 55,
    range: 2,
    vision: 4,
    domain: 'water',
    carry: { hold: { max: 3 } },
  },
  {
    // 希腊重装步兵：方阵的核心。攻击不高，但 5 点护甲让民兵几乎打不动
    id: 'anc_hoplite',
    name: '重装步兵',
    short: '重',
    era: 2,
    category: 'combat',
    cost: 58,
    move: 2,
    atk: 16,
    armor: 5,
    maxHp: 46,
    range: 1,
    vision: 2,
    abilities: ['shield-wall'],
  },
  {
    // 希腊/罗马弩炮：射程压过所有弓手，靠破甲啃方阵
    id: 'anc_ballista',
    name: '弩炮',
    short: '弩',
    era: 2,
    category: 'combat',
    cost: 64,
    move: 1,
    atk: 17,
    armor: 1,
    maxHp: 24,
    range: 4,
    vision: 2,
    abilities: ['armor-pierce'],
  },
  {
    // 罗马军团兵：站住就有光环，是"阵型"这个概念的第一次兑现
    id: 'anc_legionary',
    name: '军团兵',
    short: '团',
    era: 2,
    category: 'combat',
    cost: 62,
    move: 2,
    atk: 19,
    armor: 4,
    maxHp: 42,
    range: 1,
    vision: 2,
    abilities: ['shield-wall', 'aura-command'],
  },
  {
    // 印度/迦太基战象：一堵会走的墙。kamikaze 表示溃散时会踩自己人
    id: 'anc_elephant',
    name: '战象',
    short: '象',
    era: 2,
    category: 'combat',
    cost: 72,
    move: 2,
    atk: 24,
    armor: 4,
    maxHp: 58,
    range: 1,
    vision: 2,
    abilities: ['kamikaze'],
  },
];

/* ================================================================== */
/* 时代 3 · 火器（原版 11 个 → 模组 13 个）                            */
/* ================================================================== */

/**
 * ── 地雷：把"布一片、逼你绕"这件事做进时代军备 ─────────────────────────
 *
 * 引擎里已经有两套现成的东西：留痕（`core/marks.ts`）和回合开始钩子。
 * 海军包的水雷、奇想包的哥布林陷阱都走这条路，这里只是把"陆地上的雷"
 * 补上——而且**分轻雷/重雷两种**，因为它对应两种不同的战术：
 *
 *   · **轻雷（16 点）**：便宜、能铺、封路口。踩一发不致命，但足够让对面
 *     绕远道或者先派人趟雷，那一两个回合就是你要的。
 *   · **重雷（30 点）**：贵、上限低（4 枚），专门用来挡装甲和攻城器。
 *     一个 100 血的坦克踩两发就得回城修，攻城槌这种慢速单位基本等于被钉住。
 *
 * 两条能力的实现几乎一样，所以共用 `makeMineLayer`——差别全在参数里。
 */
const LAND_MINE_KIND: MarkKindDef = {
  id: 'era-mine',
  name: '地雷',
  summary: '敌人踩上来就炸 16 点（无视护甲），炸完就没。自己人踩不到。',
  tags: ['mine', 'land'],
  hidden: true,
  // 能埋的地面：平地、林间、丘陵、沙丘、谷地、台地。
  // 高山和城市排除：前者上不去，后者是别人的地板。
  on: ['plain', 'forest', 'hill', 'dune', 'valley', 'plateau', 'marsh'],
  trigger: 'enemy',
  detect: 1,
  onEnter: (c) => {
    if (!c.unit) return;
    const def = c.api.utype(c.unit.type);
    // 扫雷兵踩上去只挨一半：它知道怎么踩。判定挂在"雷"这一边，
    // 换一个兵来踩就该吃满伤害（和海军的水雷同一个写法）。
    const swept = (def.abilities ?? []).includes('clear-mines');
    const dmg = swept ? 8 : 16;
    c.api.hurt(c.unit, dmg, `${def.name} 踩中地雷，损失 ${dmg} 点生命`);
    c.api.log(c.mark.owner, `地雷命中 ${def.name}`);
  },
};

const AT_MINE_KIND: MarkKindDef = {
  id: 'era-at-mine',
  name: '反装甲雷',
  summary: '敌人踩上来就炸 30 点（无视护甲），炸完就没。专治重甲与攻城器。',
  tags: ['mine', 'land'],
  hidden: true,
  on: ['plain', 'forest', 'hill', 'dune', 'valley', 'plateau', 'marsh'],
  trigger: 'enemy',
  detect: 1,
  onEnter: (c) => {
    if (!c.unit) return;
    const def = c.api.utype(c.unit.type);
    const swept = (def.abilities ?? []).includes('clear-mines');
    const dmg = swept ? 15 : 30;
    c.api.hurt(c.unit, dmg, `${def.name} 触发了反装甲雷，损失 ${dmg} 点生命`);
    c.api.log(c.mark.owner, `反装甲雷命中 ${def.name}`);
  },
};

/**
 * 布雷：自己回合开始时，在两格以内埋一枚，全场上限 `cap` 枚。
 *
 * 三条细节都是踩过坑的（海军包的布雷舰先踩过一遍）：
 *   · 半径 2 而不是四邻——四邻只能围出一个圈，围不出"雷区"；
 *   · 挑格按回合号轮转——永远挑第一个的话，蹲着不动会把雷全堆在同一格；
 *   · 有自己人站着的格子跳过——埋在自己人脚下永远炸不到人。
 */
function makeMineLayer(kind: string, cap: number, label: string): AbilityDef {
  return {
    id: kind === 'era-mine' ? 'lay-mines' : 'lay-at-mines',
    name: label,
    summary: `自己回合开始时，在两格以内埋一枚${label.replace('布', '')}（全场最多 ${cap} 枚，只炸敌人）。`,
    group: 'support',
    hooks: {
      onTurnStart: [
        {
          stage: TURN_START.support,
          apply: (c) => {
            const s = c.state;
            if (markCountOf(s, kind, c.owner) >= cap) return;
            const kinds = markKindOf(kind);
            const terrenos = kinds?.on ?? [];
            const spots: Array<{ x: number; y: number }> = [];
            for (let dy = -2; dy <= 2; dy += 1) {
              for (let dx = -2; dx <= 2; dx += 1) {
                if (dx === 0 && dy === 0) continue;
                if (Math.abs(dx) + Math.abs(dy) > 2) continue;
                const x = c.self.x + dx;
                const y = c.self.y + dy;
                if (x < 0 || y < 0 || x >= s.w || y >= s.h) continue;
                const tile = s.tiles[y * s.w + x];
                if (!tile || !terrenos.includes(tile.terrain)) continue;
                if (tile.cityId) continue; // 城里是别人的地板
                if (marksAt(s, x, y).length > 0) continue; // 一格只放一件
                const stack = s.units.filter((u) => u.x === x && u.y === y && u.owner === c.owner && u.hp > 0);
                if (stack.length > 0) continue; // 自己人脚下埋了也白搭
                spots.push({ x, y });
              }
            }
            if (spots.length === 0) return;
            const pick = spots[(s.turn + c.self.x + c.self.y) % spots.length]!;
            addMark(s, { kind, owner: c.owner, x: pick.x, y: pick.y, charges: 1, hidden: true });
            c.api.pushLog(
              s,
              c.owner,
              `${c.api.utype(s, c.self.type).name} 在 ${String.fromCharCode(65 + pick.x)}${pick.y + 1} 埋下一枚${label.replace('布', '')}`,
            );
          },
        },
      ],
    },
  };
}

const LAY_MINES: AbilityDef = makeMineLayer('era-mine', 6, '布雷');
const LAY_AT_MINES: AbilityDef = makeMineLayer('era-at-mine', 4, '布反装甲雷');

/** 扫雷兵：回合开始清掉相邻的敌方雷，自己踩雷只吃一半 */
const CLEAR_MINES: AbilityDef = {
  id: 'clear-mines',
  name: '扫雷',
  summary: '自己回合开始时清掉相邻的敌方地雷；自己踩雷只受一半伤害。',
  group: 'support',
  hooks: {
    onTurnStart: [
      {
        stage: TURN_START.support,
        apply: (c) => {
          const s = c.state;
          let cleared = 0;
          for (const m of marksOf(s)) {
            if (m.owner === c.owner) continue;
            if (!markKindOf(m.kind)?.tags?.includes('mine')) continue;
            if (c.api.distance(m, c.self) > 1) continue;
            removeMark(s, m.id);
            cleared += 1;
          }
          if (cleared > 0) {
            c.api.pushLog(s, c.owner, `${c.api.utype(s, c.self.type).name} 排掉 ${cleared} 枚地雷`);
          }
        },
      },
    ],
  },
};

/**
 * 三个布雷/扫雷单位。
 *
 * 放在"谁的时代"里是有讲究的：
 *   · **工兵（3 代）**：火器时代的堑壕战就是这么开场的——先挖、再埋、最后才上。
 *     它自己打得很难看（10 攻），价值全在那片地上。
 *   · **扫雷兵（4 代）**：有雷就得有解法，否则地雷会变成单向的作弊。
 *     它的攻击也很弱，定位是"给部队开路"，不是输出。
 *   · **布雷车（5 代）**：机械化布雷，重雷一次一片，专门用来废掉对面的装甲矛头。
 */
/*
 * 每个包只登记**自己用得到的那一条**：
 *   火器包 → 布雷（lay-mines）+ 地雷；蒸汽包 → 扫雷（clear-mines）+ 地雷；机械化包 → 反装甲雷。
 * 三条都往三个包里塞会撞上 test-rules 的「能力各归各家」——那条用例守的就是
 * "同一条能力不许在两处各写一份"（重复的那份会静默失效，改的人还以为生效了）。
 *
 * 代价是：只开蒸汽包时，游戏里既没有布雷的兵、也没有雷可扫，扫雷兵是空转的。
 * 这是**接受**的——单开蒸汽包本来就没有地雷战这条线。
 */

const MINE_UNITS_GUNPOWDER: UnitTypeDef[] = [
  {
    id: 'combat-engineer',
    name: '工兵',
    short: '工',
    era: 3,
    category: 'combat',
    cost: 130,
    move: 3,
    atk: 10,
    armor: 2,
    maxHp: 32,
    range: 1,
    vision: 4,
    abilities: ['lay-mines'],
  },
];

const MINE_UNITS_INDUSTRY: UnitTypeDef[] = [
  {
    id: 'mine-sweeper',
    name: '扫雷兵',
    short: '扫',
    era: 4,
    category: 'combat',
    cost: 110,
    move: 3,
    atk: 12,
    armor: 3,
    maxHp: 34,
    range: 1,
    vision: 5,
    abilities: ['clear-mines'],
  },
];

const MINE_UNITS_MODERN: UnitTypeDef[] = [
  {
    id: 'minelayer-truck',
    name: '布雷车',
    short: '雷',
    era: 5,
    category: 'combat',
    cost: 260,
    move: 4,
    atk: 14,
    armor: 6,
    maxHp: 60,
    range: 1,
    vision: 5,
    abilities: ['lay-at-mines'],
  },
];

const GUNPOWDER: UnitTypeDef[] = [
  {
    // 线列步兵：排队枪毙的主角，站住齐射比散开强
    id: 'gp_lineinfantry',
    name: '线列步兵',
    short: '列',
    era: 3,
    category: 'combat',
    cost: 150,
    move: 2,
    atk: 22,
    armor: 3,
    maxHp: 40,
    range: 4,
    vision: 3,
    abilities: ['armor-pierce', 'shield-wall'],
  },
  {
    // 掷弹兵：先扔一轮手榴弹再冲锋，所以有溅射
    id: 'gp_grenadier',
    name: '掷弹兵',
    short: '弹',
    era: 3,
    category: 'combat',
    cost: 165,
    move: 2,
    atk: 26,
    armor: 4,
    maxHp: 44,
    range: 3,
    vision: 3,
    splash: 1,
  },
  {
    // 胸甲骑兵：火器时代最后的骑兵冲锋，甲厚、贵、怕枪
    id: 'gp_cuirassier',
    name: '胸甲骑兵',
    short: '胸',
    era: 3,
    category: 'combat',
    cost: 185,
    move: 4,
    atk: 30,
    armor: 7,
    maxHp: 46,
    range: 1,
    vision: 3,
  },
  {
    // 龙骑兵：骑马机动、下马射击，是火力与速度的结合
    id: 'gp_dragoon',
    name: '龙骑兵',
    short: '龙',
    era: 3,
    category: 'combat',
    cost: 155,
    move: 4,
    atk: 22,
    armor: 3,
    maxHp: 38,
    range: 3,
    vision: 4,
  },
  {
    // 猎兵：射程最远的散兵。
    // 第一版给了 first-strike（不挨反击），实测直接失衡：140 金打出每百金 61.7 杀伤、
    // 交换比 5.65，比同代火枪兵高 76%——"射程 5 + 不吃反击 + 潜行"等于无风险打靶。
    // 现在只保留潜行，射程收到 4、攻击 28→24，回到"视野好、能阴人、但被贴上就死"的定位。
    id: 'gp_sharpshooter',
    name: '猎兵',
    short: '猎',
    era: 3,
    category: 'combat',
    cost: 140,
    move: 2,
    atk: 19,
    armor: 1,
    maxHp: 24,
    range: 4,
    vision: 5,
    abilities: ['stealth'],
  },
  {
    // 攻城加农炮：火器时代的攻城核心，两格溅射
    id: 'gp_siegecannon',
    name: '攻城加农炮',
    short: '加',
    era: 3,
    category: 'combat',
    cost: 160,
    move: 1,
    atk: 30,
    armor: 3,
    maxHp: 36,
    range: 5,
    vision: 2,
    splash: 2,
    abilities: ['siege-master'],
  },
  {
    // 康格里夫火箭：射程远、精度差、声光吓人。
    // 名字必须带「康格里夫」——只叫"火箭"会和「火箭炮」（现代 mod_katyusha）、
    // 「火箭兵」这类词撞在一起，表格和战报里根本分不清说的是哪一个。
    id: 'gp_rocket',
    name: '康格里夫火箭',
    short: '箭',
    era: 3,
    category: 'combat',
    cost: 150,
    move: 2,
    atk: 24,
    armor: 1,
    maxHp: 28,
    range: 5,
    vision: 2,
    splash: 1,
  },
  {
    // 长管炮：射程最远的直射火力，靠破甲啃棱堡
    id: 'gp_culverin',
    name: '长管炮',
    short: '长',
    era: 3,
    category: 'combat',
    cost: 170,
    move: 1,
    atk: 28,
    armor: 3,
    maxHp: 34,
    range: 6,
    vision: 2,
    abilities: ['armor-pierce', 'siege-master'],
  },
  {
    // 棱堡：星形要塞的角楼，射界没有死角
    id: 'gp_bastion',
    name: '棱堡',
    short: '棱',
    era: 3,
    category: 'building',
    cost: 200,
    move: 0,
    atk: 24,
    armor: 11,
    maxHp: 70,
    range: 4,
    vision: 5,
    splash: 1,
    autoAttack: true,
  },
  {
    // 防马桩：最便宜的延迟工事，专治骑兵冲脸
    id: 'gp_chevaux',
    name: '防马桩',
    short: '桩',
    era: 3,
    category: 'building',
    cost: 70,
    move: 0,
    atk: 0,
    armor: 6,
    maxHp: 50,
    range: 1,
    vision: 1,
    obstacle: true,
  },
  {
    // 土垒胸墙：沃邦之前的野战筑城做法，夯土加木排，专门用来吃炮弹。
    // 城墙这条线的第三环：比棱堡便宜得多，但没有射界、没有溅射，纯粹是"别过来"。
    id: 'gp_earthwork',
    name: '土垒胸墙',
    short: '垒',
    era: 3,
    category: 'building',
    cost: 120,
    move: 0,
    atk: 0,
    armor: 10,
    maxHp: 110,
    range: 1,
    vision: 1,
    obstacle: true,
  },
  {
    // 军需官：火器时代军队规模爆炸，后勤本身成了兵种
    id: 'gp_quartermaster',
    name: '军需官',
    short: '需',
    era: 3,
    category: 'economy',
    cost: 150,
    move: 2,
    atk: 4,
    armor: 2,
    maxHp: 24,
    range: 1,
    vision: 3,
    incomeByTerrain: { city: 16, plain: 9, hill: 5, forest: 4 },
  },
  {
    // 工兵：棱堡与防马桩的施工方
    id: 'gp_sapper',
    name: '坑道工兵',
    short: '坑',
    era: 3,
    category: 'builder',
    cost: 135,
    move: 2,
    atk: 5,
    armor: 3,
    maxHp: 24,
    range: 1,
    vision: 2,
    builds: ['gp_chevaux', 'gp_earthwork', 'gp_bastion', 'bridge2', 'camp3'],
  },
  {
    // 风帆战列舰：三层甲板、一百门炮，火器时代的海上霸主
    id: 'gp_shipofline',
    name: '风帆战列舰',
    short: '战',
    era: 3,
    category: 'combat',
    cost: 205,
    move: 4,
    atk: 34,
    armor: 8,
    maxHp: 80,
    range: 4,
    vision: 4,
    domain: 'water',
  },
];

/* ================================================================== */
/* 时代 4 · 蒸汽（原版 7 个 → 模组 13 个）                             */
/* ================================================================== */

const INDUSTRY: UnitTypeDef[] = [
  {
    // 战壕迫击炮（斯托克斯式，1915）：堑壕战的产物，曲射、轻便、跟着步兵走。
    // 这里原本是「骑兵」——蒸汽化时代还让骑兵当主力太违和（一战骑兵确实存在，
    // 但只在战争初期和东线还有用，本作没法表达"被机枪压制"这件事）。
    // 换成迫击炮之后，这一档正好补上蒸汽包缺失的"步兵伴随火力"：
    // 射程比榴弹炮近、比手榴弹远，价格只有榴弹炮的七成。
    id: 'ind_trenchmortar',
    name: '战壕迫击炮',
    short: '壕',
    era: 4,
    category: 'combat',
    cost: 200,
    move: 2,
    atk: 26,
    armor: 3,
    maxHp: 32,
    range: 4,
    vision: 2,
    splash: 1,
  },
  {
    // 堑壕突击队：穿越无人区的那批人，潜行是他们的生存技能。
    // 第一版 210 金 / atk 34 / 射程 2，和步枪兵（200 金 / atk 36 / 射程 4）比全面更差，
    // 实测每百金 8.6。现在改成"近战爆发"：射程 3、攻击 42、价格 195，
    // 用射程换攻击——它不该是步枪兵的下位替代品。
    id: 'ind_trenchraider',
    name: '堑壕突击队',
    short: '突',
    era: 4,
    category: 'combat',
    cost: 195,
    move: 2,
    atk: 42,
    armor: 3,
    maxHp: 40,
    range: 3,
    vision: 3,
    abilities: ['stealth'],
  },
  {
    // 火焰喷射器：射程只有 2，但在那一格里它就是神
    id: 'ind_flamethrower',
    name: '火焰喷射器',
    short: '焰',
    era: 4,
    category: 'combat',
    cost: 215,
    move: 2,
    atk: 42,
    armor: 3,
    maxHp: 36,
    range: 2,
    vision: 2,
    splash: 1,
  },
  {
    // 毒气兵：无视护甲的成片杀伤，代价是短射程和脆。
    // 实测每百金 18.3（步枪兵 35.9）：溅射要靠敌人扎堆，而 AI 的阵型是散开的。
    // 攻击 32→36 补一点单体伤害，别让它只能在"对方自己站成一排"时才有用。
    id: 'ind_gas',
    name: '毒气兵',
    short: '毒',
    era: 4,
    category: 'combat',
    cost: 230,
    move: 2,
    atk: 36,
    armor: 3,
    maxHp: 36,
    range: 3,
    vision: 2,
    splash: 2,
    abilities: ['armor-pierce'],
  },
  {
    // 榴弹炮：曲射，射程 6，专门拆堑壕体系
    id: 'ind_howitzer',
    name: '榴弹炮',
    short: '榴',
    era: 4,
    category: 'combat',
    cost: 225,
    move: 1,
    atk: 38,
    armor: 4,
    maxHp: 42,
    range: 6,
    vision: 2,
    splash: 2,
    abilities: ['siege-master'],
  },
  {
    // 列车炮：射程 7，全游戏最远。挪一次要半个回合
    id: 'ind_railwaygun',
    name: '列车炮',
    short: '列',
    era: 4,
    category: 'combat',
    cost: 265,
    move: 1,
    atk: 44,
    armor: 6,
    maxHp: 60,
    range: 7,
    vision: 2,
    splash: 2,
    abilities: ['siege-master'],
  },
  {
    // 马克 I 型：第一次上战场的坦克，慢、笨、但步枪打不穿
    id: 'ind_landship',
    name: '马克 I 坦克',
    short: '坦',
    era: 4,
    category: 'combat',
    cost: 330,
    move: 2,
    atk: 30,
    armor: 10,
    maxHp: 80,
    range: 2,
    vision: 2,
    abilities: ['siege-master'],
  },
  {
    // 装甲列车：一战东线的主角，一门炮加几挺机枪装在铁路上。
    // 本作没有轨道机制，所以按普通地面单位处理（说明列里注明这一点）。
    // 第一版 atk 40 + burst 2，实测每百金 48.1、交换比 3.69，是全包最高（步枪兵 23.9）——
    // 射程 4 加护甲 9 让它站在后排既打得到人又不挨打。攻击收到 34，保留连发作卖点。
    id: 'ind_armoredtrain',
    name: '装甲列车',
    short: '轨',
    era: 4,
    category: 'combat',
    cost: 340,
    move: 2,
    atk: 34,
    armor: 9,
    maxHp: 70,
    range: 4,
    vision: 3,
    burst: 2,
    abilities: ['siege-master'],
  },
  {
    // 机枪碉堡：把 burst 装进建筑，谁靠近谁碎
    id: 'ind_pillbox',
    name: '机枪碉堡',
    short: '碉',
    era: 4,
    category: 'building',
    cost: 225,
    move: 0,
    atk: 28,
    armor: 10,
    maxHp: 60,
    range: 4,
    vision: 3,
    burst: 3,
    autoAttack: true,
  },
  {
    // 铁丝网：不为杀伤，只为把"一步"变成"三步"
    id: 'ind_wire',
    name: '铁丝网',
    short: '网',
    era: 4,
    category: 'building',
    cost: 60,
    move: 0,
    atk: 4,
    armor: 4,
    maxHp: 40,
    range: 1,
    vision: 1,
    obstacle: true,
  },
  {
    // 混凝土胸墙：钢筋水泥浇筑的固定工事，一战西线战壕的"硬边"。
    // 城墙线第四环：护甲 14 + 血量 150，是这个时代唯一能用钱堆出来的"过不去"。
    id: 'ind_concrete',
    name: '混凝土胸墙',
    short: '砼',
    era: 4,
    category: 'building',
    cost: 150,
    move: 0,
    atk: 0,
    armor: 14,
    maxHp: 150,
    range: 1,
    vision: 1,
    obstacle: true,
  },
  {
    // 钢厂：蒸汽时代的经济建筑，站在城里最赚
    id: 'ind_steelworks',
    name: '钢厂',
    short: '钢',
    era: 4,
    category: 'building',
    cost: 300,
    move: 0,
    atk: 4,
    armor: 7,
    maxHp: 55,
    range: 1,
    vision: 2,
    incomeByTerrain: { city: 34, plain: 16, hill: 10, forest: 8 },
  },
  {
    // 工兵：铁丝网、机枪碉堡、兵站
    id: 'ind_sapper',
    name: '战地工兵',
    short: '地',
    era: 4,
    category: 'builder',
    cost: 210,
    move: 2,
    atk: 5,
    armor: 3,
    maxHp: 26,
    range: 1,
    vision: 2,
    builds: ['ind_wire', 'ind_concrete', 'ind_pillbox', 'ind_steelworks', 'bridge2', 'camp4'],
  },
  {
    // 驱逐舰：蒸汽时代的海上多面手，带一点溅射
    id: 'ind_destroyer',
    name: '雷击舰',
    short: '雷',
    era: 4,
    category: 'combat',
    cost: 285,
    move: 5,
    atk: 38,
    armor: 8,
    maxHp: 75,
    range: 4,
    vision: 4,
    splash: 1,
    domain: 'water',
  },
];

/* ================================================================== */
/* 时代 5 · 现代（原版 11 个 → 模组 13 个）                            */
/* ================================================================== */

const MODERN: UnitTypeDef[] = [
  {
    // 伞兵：视野最高的步兵，专门找火炮和后方城市
    id: 'mod_paratrooper',
    name: '伞兵',
    short: '伞',
    era: 5,
    category: 'combat',
    cost: 340,
    move: 4,
    atk: 41,
    armor: 4,
    maxHp: 48,
    range: 3,
    vision: 5,
  },
  {
    // 突击队：潜行 + 高攻，用来捅后排。
    // 第一版射程 2、330 金，实测每百金 6.7，是全包最差——"潜行贴近"在 AI 手里等于送死。
    // 射程放到 3、价格降到 310，让它先能站着输出。
    id: 'mod_commando',
    name: '突击队',
    short: '击',
    era: 5,
    category: 'combat',
    cost: 310,
    move: 3,
    atk: 42,
    armor: 4,
    maxHp: 46,
    range: 3,
    vision: 4,
    abilities: ['stealth'],
  },
  {
    // 反坦克炮：破甲 + 先手，专治重装甲
    id: 'mod_atgun',
    name: '反坦克炮',
    short: '反',
    era: 5,
    category: 'combat',
    cost: 260,
    move: 1,
    atk: 54,
    armor: 3,
    maxHp: 34,
    range: 4,
    vision: 3,
    abilities: ['armor-pierce', 'first-strike'],
  },
  {
    // 喀秋莎：一片覆盖，精度靠密度。
    // 削了两轮才收住：第一版 atk 50 / 射程 6，交换比 5.64；降到 atk 46 后反而升到 7.48
    // （承伤只有 633——射程 6 在这套对局里几乎不可能被摸到）。
    // 真正的病根不是攻击而是**射程**：原版火炮是 5。现在收回 5，保留 splash 2 作为卖点。
    id: 'mod_katyusha',
    name: '火箭炮',
    short: '喀',
    era: 5,
    category: 'combat',
    cost: 310,
    move: 2,
    atk: 46,
    armor: 5,
    maxHp: 46,
    range: 5,
    vision: 2,
    splash: 2,
    abilities: ['siege-master'],
  },
  {
    // 重型坦克：装甲 14，正面几乎无解，代价是慢和贵
    id: 'mod_heavytank',
    name: '重型坦克',
    short: '重',
    era: 5,
    category: 'combat',
    cost: 480,
    move: 3,
    atk: 60,
    armor: 14,
    maxHp: 100,
    range: 3,
    vision: 3,
    abilities: ['siege-master'],
  },
  {
    // 自行火炮：能自己跑的火炮，打一轮换一个地方。
    // 实测交换比 2.35，是原版火炮（2.07）之上——射程 5 + 溅射 2 + 能移动太全能。
    // 攻击 54→50 收一点，保留机动性这个卖点。
    // 第三轮仍偏强（交换比 9.19、承伤只有 293）：病根和火箭炮一样是射程，
    // 不是攻击——move 3 + 射程 5 让它永远够得着别人。射程收到 4，攻击 50→42。
    id: 'mod_spg',
    name: '自行火炮',
    short: '自',
    era: 5,
    category: 'combat',
    cost: 340,
    move: 3,
    atk: 42,
    armor: 8,
    maxHp: 62,
    range: 4,
    vision: 2,
    splash: 2,
    abilities: ['siege-master'],
  },
  {
    // 高射炮：平射时是一串连发，burst 2
    id: 'mod_flak',
    name: '高射炮',
    short: '空',
    era: 5,
    category: 'combat',
    cost: 290,
    move: 1,
    atk: 46,
    armor: 4,
    maxHp: 40,
    range: 4,
    vision: 3,
    burst: 2,
  },
  {
    // 反坦克拒马：现代最便宜的"别过来"
    id: 'mod_dragonsteeth',
    name: '反坦克拒马',
    short: '拒',
    era: 5,
    category: 'building',
    cost: 70,
    move: 0,
    atk: 0,
    armor: 10,
    maxHp: 70,
    range: 1,
    vision: 1,
    obstacle: true,
  },
  {
    // 混凝土掩体墙：城墙线第五环。到这个时代它已经变成"纯粹的路障"——
    // 240 金换 200 血 + 18 护甲，比同价战斗单位耐得多，但一步都走不了。
    id: 'mod_concretewall',
    name: '混凝土掩体墙',
    short: '壁',
    era: 5,
    category: 'building',
    cost: 195,
    move: 0,
    atk: 0,
    armor: 18,
    maxHp: 200,
    range: 1,
    vision: 1,
    obstacle: true,
  },
  {
    // 机枪地堡：混凝土 + 重机枪，现代防线的核心
    id: 'mod_mgbunker',
    name: '重机枪地堡',
    short: '垒',
    era: 5,
    category: 'building',
    cost: 330,
    move: 0,
    atk: 32,
    armor: 15,
    maxHp: 90,
    range: 4,
    vision: 3,
    burst: 4,
    autoAttack: true,
  },
  {
    // 补给车队：现代战争打的是后勤，收入随地形
    id: 'mod_supply',
    name: '补给车队',
    short: '补',
    era: 5,
    category: 'economy',
    cost: 285,
    move: 3,
    atk: 4,
    armor: 4,
    maxHp: 34,
    range: 1,
    vision: 3,
    incomeByTerrain: { city: 30, plain: 18, hill: 10, forest: 9 },
  },
  {
    // 工兵：拒马、机枪地堡、钢桥、前进基地
    id: 'mod_pioneer',
    name: '战斗工兵',
    short: '战',
    era: 5,
    category: 'builder',
    cost: 265,
    move: 2,
    atk: 5,
    armor: 4,
    maxHp: 30,
    range: 1,
    vision: 2,
    builds: ['mod_dragonsteeth', 'mod_concretewall', 'mod_mgbunker', 'bridge3', 'camp5'],
  },
  {
    // 驱逐舰：现代海军的通用平台
    id: 'mod_destroyer',
    name: '驱逐舰',
    short: '舰',
    era: 5,
    category: 'combat',
    cost: 360,
    move: 5,
    atk: 52,
    armor: 11,
    maxHp: 100,
    range: 5,
    vision: 5,
    domain: 'water',
    abilities: ['armor-pierce'],
  },
  {
    // 重型迫击炮：便宜、射程近、胜在能跟着步兵走
    id: 'mod_heavy_mortar',
    name: '重型迫击炮',
    short: '迫',
    era: 5,
    category: 'combat',
    cost: 260,
    move: 2,
    atk: 38,
    armor: 3,
    maxHp: 30,
    range: 4,
    vision: 2,
    splash: 1,
  },
];

/* ================================================================== */
/* 注册                                                                */
/* ================================================================== */

/**
 * 「时代军备」：五个时代各一组兵，外加第六时代的专精兵。
 *
 * ---------------------------------------------------------------
 * 为什么从一个包变一个包（2026-11-04）
 * ---------------------------------------------------------------
 * 以前这里是五个包（青铜会战 / 铁器兵备 / 火器列国 / 蒸汽绞肉机 / 机械化合成兵），
 * 第六时代的「现代战争」是第六个。六个包说的是同一件事：**这一代还有哪些兵可选**。
 * 但玩家每开一局都要在开局面板里把它们找六遍，而且很容易只勾一两个就以为
 * "军备包开完了"——那是个界面问题，不是设计意图。
 *
 * 合并之后只剩一个勾：勾上就是"每一代都有额外的兵"。
 *
 * ---------------------------------------------------------------
 * 第六时代那 15 个专精兵为什么还留着条件
 * ---------------------------------------------------------------
 * 它们的 `requiresPack` 是「信息化」：那一代是「信息化」这个包开出来的
 * （`unlockEra: 6`），不勾它城市永远升不到 6 级，这批兵一个都造不出来。
 * 挂在同一个包里、靠 `requiresPack` 门控，好处是玩家不用理解"第六代还有两个包"，
 * 坏处是勾了这个包却没勾「信息化」时，兵种池里会少一截——所以开局面板的
 * 兵种池弹层用的是 `expansionUnitsFor`，和真正开局**同一套判据**，两边不会打架。
 */
export const ERA_ARMS: Expansion = {
  id: 'era-arms',
  scale: 'large',
  name: '时代军备',
  blurb: '每一代都多一批可选兵种。',
  summary:
    '每一代都多出一批可选兵种：青铜的投石兵/战车/攻城槌/旌旗车，铁器的瑞士长矛兵/重装军士/' +
    '战象/弩炮/攻城塔，火器的线列步兵/胸甲骑兵/猎兵/棱堡，蒸汽的堑壕突击队/火焰喷射器/' +
    '列车炮/马克 I 坦克，机械化的伞兵/突击队/喀秋莎/重型坦克；布雷与扫雷的能力也在这一包里。' +
    '另含第六时代的 15 个专精兵（机械化步兵、主战坦克、反坦克导弹、特种部队、自行榴弹炮、' +
    '远程火箭炮、防空导弹营、武装直升机、察打无人机、导弹驱逐舰、复合装甲墙、加固地堡、' +
    '前进指挥所、物流集团、工程兵团）——**这批要同时开「信息化」才会出现**，' +
    '因为第六时代是那个包开出来的。',
  hooks: {},
  abilities: [LAY_MINES, CLEAR_MINES, LAY_AT_MINES, ...MODERN_ABILITIES],
  // 两个雷种各来自不同时代：反装甲雷是机械化那一档的布雷车撒的
  marks: [LAND_MINE_KIND, AT_MINE_KIND],
  units: [
    ...ANTIQUITY,
    ...MEDIEVAL,
    ...GUNPOWDER,
    ...MINE_UNITS_GUNPOWDER,
    ...INDUSTRY,
    ...MINE_UNITS_INDUSTRY,
    ...MODERN,
    ...MINE_UNITS_MODERN,
    // 第六代的兵：靠 requiresPack 门控，不开「信息化」就不进本局兵种表
    ...CONTEMPORARY_WAR.map((u) => ({ ...u, requiresPack: 'pack-contemporary' })),
  ],
};
