import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const dir=path.dirname(fileURLToPath(import.meta.url));
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const manifest=JSON.parse(fs.readFileSync(path.join(dir,'bundle-manifest.json'),'utf8'));
for(const e of manifest.files)assert.equal(hash(fs.readFileSync(path.join(dir,e.path))),e.sha256,e.path);
const before=fs.readFileSync(path.join(dir,'comparison.json'));
for(const [cwd,script,args]of [[path.join(dir,'reference'),'extract-new.mjs',['--benchmark','.']],[path.join(dir,'reference'),'probe-new.mjs',['--benchmark','.']],[dir,'extract-new.mjs',['--benchmark','.']],[dir,'probe-new.mjs',['--benchmark','.']],[dir,'validate-and-compare.mjs',[]]]){
 console.log('RUN '+path.relative(dir,cwd)+'/'+script);
 const r=spawnSync(process.execPath,['--experimental-strip-types',script,...args],{cwd,encoding:'utf8',windowsHide:true,maxBuffer:20*1024*1024});
 process.stdout.write(r.stdout);process.stderr.write(r.stderr);assert.equal(r.status,0,script);
}
assert.equal(hash(fs.readFileSync(path.join(dir,'comparison.json'))),hash(before),'Recomputed comparison changed');
console.log(JSON.stringify({complete:true,filesVerified:manifest.files.length,nativeBeforeReplays:12,nativeAfterReplays:12,comparisonByteIdentical:true}));
