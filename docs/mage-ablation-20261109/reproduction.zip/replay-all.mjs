import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const dir=path.dirname(fileURLToPath(import.meta.url)),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const manifest=JSON.parse(fs.readFileSync(path.join(dir,'bundle-manifest.json'),'utf8'));
for(const f of manifest.files)assert.equal(hash(fs.readFileSync(path.join(dir,f.path))),f.sha256,f.path);
const before=hash(fs.readFileSync(path.join(dir,'comparison.json')));
const tasks=[['test-core','scripts/test-ai-mage-experiment.ts',[]],['test-core','scripts/test-ai-unit-strategy.ts',[]],['.','verify-isolation.mjs',[]]];
for(const folder of ['reference/original','reference/combined','.'])for(const script of ['extract-new.mjs','probe-new.mjs'])tasks.push([folder,script,['--benchmark','.']]);
tasks.push(['.','compare.mjs',[]]);
for(const [folder,script,args]of tasks){
 console.log('RUN '+folder+'/'+script);
 const r=spawnSync(process.execPath,['--experimental-strip-types',script,...args],{cwd:path.join(dir,folder),encoding:'utf8',windowsHide:true,maxBuffer:20*1024*1024});
 process.stdout.write(r.stdout);process.stderr.write(r.stderr);assert.equal(r.status,0,folder+'/'+script);
}
assert.equal(hash(fs.readFileSync(path.join(dir,'comparison.json'))),before,'Recomputed analysis changed');
console.log(JSON.stringify({complete:true,manifestFiles:manifest.files.length,nativeReplays:20,newMageTests:15,priorStrategyTests:12,comparisonByteIdentical:true}));
